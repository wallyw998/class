import { Router, Request, Response } from "express";
import { poolPromise, sql } from "../db";
import { ContratistaFormData } from "../types";

const router = Router();

// Columnas de Cntr_Datos habilitadas para búsqueda por campo
const COLUMNAS_BUSCABLES = [
  "NombreComercial",
  "CamaraPatronal",
  "ActividadScian",
  "Domicilio",
  "TipoEstablecimiento",
  "Nombre",
  "Apellido",
  "Telefono",
  "Correo",
  "SolicitantesKCM",
];

// GET /api/contratistas?nombreComercial=abc&rfc=xyz...
// Cada query param filtra esa columna con LIKE '%valor%'
router.get("/", async (req: Request, res: Response) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();

    const condiciones: string[] = [];

    for (const columna of COLUMNAS_BUSCABLES) {
      const valorQuery = req.query[columna.charAt(0).toLowerCase() + columna.slice(1)];
      if (valorQuery && typeof valorQuery === "string") {
        const parametro = `filtro_${columna}`;
        condiciones.push(`d.${columna} LIKE @${parametro}`);
        request.input(parametro, sql.NVarChar, `%${valorQuery}%`);
      }
    }

    // Filtros opcionales sobre las tablas relacionadas (RFC, RazonSocial, ClaseRiesgo)
    if (req.query.rfc && typeof req.query.rfc === "string") {
      condiciones.push("c.RFC LIKE @rfc");
      request.input("rfc", sql.NVarChar, `%${req.query.rfc}%`);
    }
    if (req.query.razonSocial && typeof req.query.razonSocial === "string") {
      condiciones.push("c.RazonSocial LIKE @razonSocial");
      request.input("razonSocial", sql.NVarChar, `%${req.query.razonSocial}%`);
    }
    if (req.query.claseRiesgo && typeof req.query.claseRiesgo === "string") {
      condiciones.push("s.ClaseRiesgo LIKE @claseRiesgo");
      request.input("claseRiesgo", sql.NVarChar, `%${req.query.claseRiesgo}%`);
    }

    const where = condiciones.length ? `WHERE ${condiciones.join(" AND ")}` : "";

    const resultado = await request.query(`
      SELECT
        d.IdContratistas, d.NombreComercial, d.CamaraPatronal, d.ActividadScian,
        d.Domicilio, d.TipoEstablecimiento, d.Nombre, d.Apellido, d.Telefono,
        d.Correo, d.PersonalRegistrado, d.SolicitantesKCM,
        c.RazonSocial, c.RFC, c.PrimaRiesgo, c.CapitalContable,
        s.RegistroPatronal, s.ClaseRiesgo,
        a.AreaTrabajo, a.DiasLaborados
      FROM Cntr_Datos d
      LEFT JOIN Cntr_Datos_Contables c ON c.IdContratistas = d.IdContratistas
      LEFT JOIN Cntr_Datos_Seguro s ON s.IdContratistas = d.IdContratistas
      LEFT JOIN Cntr_Actividades a ON a.IdContratistas = d.IdContratistas
      ${where}
      ORDER BY d.IdContratistas DESC
    `);

    res.json(resultado.recordset);
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: "Error al consultar contratistas.", error: String(error) });
  }
});

// POST /api/contratistas — guarda las 4 tablas en una sola transacción
router.post("/", async (req: Request, res: Response) => {
  const formulario = req.body as ContratistaFormData;
  const { datos, contables, seguro, actividades } = formulario;

  if (!datos?.nombreComercial || !datos?.camaraPatronal) {
    return res.status(400).json({ mensaje: "Faltan campos obligatorios de Datos Generales." });
  }

  const pool = await poolPromise;
  const transaccion = new sql.Transaction(pool);

  try {
    await transaccion.begin();

    const insertDatos = new sql.Request(transaccion);
    const resultDatos = await insertDatos
      .input("NombreComercial", sql.NVarChar, datos.nombreComercial)
      .input("CamaraPatronal", sql.NVarChar, datos.camaraPatronal)
      .input("ActividadScian", sql.NVarChar, datos.actividadScian)
      .input("Domicilio", sql.NVarChar, datos.domicilio)
      .input("TipoEstablecimiento", sql.NVarChar, datos.tipoEstablecimiento)
      .input("Nombre", sql.NVarChar, datos.nombre)
      .input("Apellido", sql.NVarChar, datos.apellido)
      .input("Telefono", sql.NVarChar, datos.telefono)
      .input("Correo", sql.NVarChar, datos.correo)
      .input("PersonalRegistrado", sql.Int, datos.personalRegistrado)
      .input("SolicitantesKCM", sql.NVarChar, datos.solicitantesKCM).query(`
        INSERT INTO Cntr_Datos
          (NombreComercial, CamaraPatronal, ActividadScian, Domicilio, TipoEstablecimiento,
           Nombre, Apellido, Telefono, Correo, PersonalRegistrado, SolicitantesKCM)
        OUTPUT INSERTED.IdContratistas
        VALUES
          (@NombreComercial, @CamaraPatronal, @ActividadScian, @Domicilio, @TipoEstablecimiento,
           @Nombre, @Apellido, @Telefono, @Correo, @PersonalRegistrado, @SolicitantesKCM)
      `);

    const idContratistas = resultDatos.recordset[0].IdContratistas as number;

    await new sql.Request(transaccion)
      .input("RazonSocial", sql.NVarChar, contables.razonSocial)
      .input("RFC", sql.NVarChar, contables.rfc)
      .input("DomicilioFiscal", sql.NVarChar, contables.domicilioFiscal)
      .input("PrimaRiesgo", sql.Decimal(5, 2), contables.primaRiesgo)
      .input("CapitalContable", sql.Decimal(18, 2), contables.capitalContable)
      .input("IdContratistas", sql.Int, idContratistas).query(`
        INSERT INTO Cntr_Datos_Contables
          (RazonSocial, RFC, DomicilioFiscal, PrimaRiesgo, CapitalContable, IdContratistas)
        VALUES (@RazonSocial, @RFC, @DomicilioFiscal, @PrimaRiesgo, @CapitalContable, @IdContratistas)
      `);

    await new sql.Request(transaccion)
      .input("RegistroPatronal", sql.NVarChar, seguro.registroPatronal)
      .input("ActividadImss", sql.NVarChar, seguro.actividadImss)
      .input("ClaseRiesgo", sql.NVarChar, seguro.claseRiesgo)
      .input("IdContratistas", sql.Int, idContratistas).query(`
        INSERT INTO Cntr_Datos_Seguro (RegistroPatronal, ActividadImss, ClaseRiesgo, IdContratistas)
        VALUES (@RegistroPatronal, @ActividadImss, @ClaseRiesgo, @IdContratistas)
      `);

    await new sql.Request(transaccion)
      .input("AccesoPlanta", sql.NVarChar, actividades.accesoPlanta)
      .input("DimensionesCons", sql.NVarChar, actividades.dimensionesCons)
      .input("Actividades", sql.NVarChar, actividades.actividades)
      .input("AreaTrabajo", sql.NVarChar, actividades.areaTrabajo)
      .input("ActividadesEnPlanta", sql.NVarChar, actividades.actividadesEnPlanta)
      .input("DiasLaborados", sql.NVarChar, actividades.diasLaborados)
      .input("IdContratistas", sql.Int, idContratistas).query(`
        INSERT INTO Cntr_Actividades
          (AccesoPlanta, DimensionesCons, Actividades, AreaTrabajo, ActividadesEnPlanta, DiasLaborados, IdContratistas)
        VALUES
          (@AccesoPlanta, @DimensionesCons, @Actividades, @AreaTrabajo, @ActividadesEnPlanta, @DiasLaborados, @IdContratistas)
      `);

    await transaccion.commit();
    res.status(201).json({ idContratistas, mensaje: "Contratista registrado correctamente." });
  } catch (error) {
    await transaccion.rollback();
    console.error(error);
    res.status(500).json({ mensaje: "Error al guardar el contratista.", error: String(error) });
  }
});

export default router;
