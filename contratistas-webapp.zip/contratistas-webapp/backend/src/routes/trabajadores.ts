import { Router, Request, Response } from "express";
import { poolPromise, sql } from "../db";
import { TrabajadorFormData } from "../types";

const router = Router();

const COLUMNAS_BUSCABLES = ["Nombre", "ApellidoP", "ApellidoM", "Cargo", "Actividad"];

// GET /api/trabajadores?nombre=juan&cargo=soldador...
router.get("/", async (req: Request, res: Response) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();
    const condiciones: string[] = [];

    for (const columna of COLUMNAS_BUSCABLES) {
      const clave = columna.charAt(0).toLowerCase() + columna.slice(1);
      const valorQuery = req.query[clave];
      if (valorQuery && typeof valorQuery === "string") {
        const parametro = `filtro_${columna}`;
        condiciones.push(`t.${columna} LIKE @${parametro}`);
        request.input(parametro, sql.NVarChar, `%${valorQuery}%`);
      }
    }

    if (req.query.curp && typeof req.query.curp === "string") {
      condiciones.push("p.CURP LIKE @curp");
      request.input("curp", sql.NVarChar, `%${req.query.curp}%`);
    }
    if (req.query.telefono && typeof req.query.telefono === "string") {
      condiciones.push("p.Telefono LIKE @telefono");
      request.input("telefono", sql.NVarChar, `%${req.query.telefono}%`);
    }

    const where = condiciones.length ? `WHERE ${condiciones.join(" AND ")}` : "";

    const resultado = await request.query(`
      SELECT
        t.IdTrabajador, t.Nombre, t.ApellidoP, t.ApellidoM, t.Cargo, t.Actividad, t.IdContratista,
        p.NumImss, p.Direccion, p.CURP, p.Telefono
      FROM Cntr_Trabajador t
      LEFT JOIN Cntr_Datos_Per p ON p.IdTrabajador = t.IdTrabajador
      ${where}
      ORDER BY t.IdTrabajador DESC
    `);

    res.json(resultado.recordset);
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: "Error al consultar trabajadores.", error: String(error) });
  }
});

// POST /api/trabajadores
router.post("/", async (req: Request, res: Response) => {
  const formulario = req.body as TrabajadorFormData;
  const { trabajador, datosPersonales } = formulario;

  if (!trabajador?.nombre || !trabajador?.apellidoP || !trabajador?.idContratista) {
    return res.status(400).json({ mensaje: "Faltan campos obligatorios del trabajador." });
  }

  const pool = await poolPromise;
  const transaccion = new sql.Transaction(pool);

  try {
    await transaccion.begin();

    const insertTrabajador = new sql.Request(transaccion);
    const resultTrabajador = await insertTrabajador
      .input("Nombre", sql.NVarChar, trabajador.nombre)
      .input("ApellidoP", sql.NVarChar, trabajador.apellidoP)
      .input("ApellidoM", sql.NVarChar, trabajador.apellidoM)
      .input("Cargo", sql.NVarChar, trabajador.cargo)
      .input("Actividad", sql.NVarChar, trabajador.actividad)
      .input("IdContratista", sql.Int, trabajador.idContratista).query(`
        INSERT INTO Cntr_Trabajador (Nombre, ApellidoP, ApellidoM, Cargo, Actividad, IdContratista)
        OUTPUT INSERTED.IdTrabajador
        VALUES (@Nombre, @ApellidoP, @ApellidoM, @Cargo, @Actividad, @IdContratista)
      `);

    const idTrabajador = resultTrabajador.recordset[0].IdTrabajador as number;

    await new sql.Request(transaccion)
      .input("IdTrabajador", sql.Int, idTrabajador)
      .input("NumImss", sql.NVarChar, datosPersonales.numImss)
      .input("Direccion", sql.NVarChar, datosPersonales.direccion)
      .input("CURP", sql.NVarChar, datosPersonales.curp)
      .input("Telefono", sql.NVarChar, datosPersonales.telefono).query(`
        INSERT INTO Cntr_Datos_Per (IdTrabajador, NumImss, Direccion, CURP, Telefono)
        VALUES (@IdTrabajador, @NumImss, @Direccion, @CURP, @Telefono)
      `);

    await transaccion.commit();
    res.status(201).json({ idTrabajador, mensaje: "Trabajador registrado correctamente." });
  } catch (error) {
    await transaccion.rollback();
    console.error(error);
    res.status(500).json({ mensaje: "Error al guardar el trabajador.", error: String(error) });
  }
});

export default router;
