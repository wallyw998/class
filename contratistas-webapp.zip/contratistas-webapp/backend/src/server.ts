import express from "express";
import cors from "cors";
import "dotenv/config";
import contratistasRouter from "./routes/contratistas";
import trabajadoresRouter from "./routes/trabajadores";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors()); // en producción, restringe a tu dominio del frontend
app.use(express.json());

app.use("/api/contratistas", contratistasRouter);
app.use("/api/trabajadores", trabajadoresRouter);

app.get("/api/health", (_req, res) => {
  res.json({ estado: "ok" });
});

app.listen(PORT, () => {
  console.log(`API escuchando en http://localhost:${PORT}`);
});
