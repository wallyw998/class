// =========================================================
// Tipos compartidos — reflejan las tablas de SQL Server
// =========================================================

export interface DatosContratista {
  idContratistas?: number;
  nombreComercial: string;
  camaraPatronal: string;
  actividadScian: string;
  domicilio: string;
  tipoEstablecimiento: string;
  nombre: string;
  apellido: string;
  telefono: string;
  correo: string;
  personalRegistrado: number | null;
  solicitantesKCM: string;
}

export interface DatosContables {
  idDatosContables?: number;
  razonSocial: string;
  rfc: string;
  domicilioFiscal: string;
  primaRiesgo: number;
  capitalContable: number | null;
  idContratistas?: number;
}

export interface DatosSeguro {
  idDatosSeguro?: number;
  registroPatronal: string;
  actividadImss: string;
  claseRiesgo: string;
  idContratistas?: number;
}

export interface Actividades {
  idActividades?: number;
  accesoPlanta: string;
  dimensionesCons: string;
  actividades: string;
  areaTrabajo: string;
  actividadesEnPlanta: string;
  diasLaborados: string;
  idContratistas?: number;
}

export interface ContratistaFormData {
  datos: DatosContratista;
  contables: DatosContables;
  seguro: DatosSeguro;
  actividades: Actividades;
}

export interface Trabajador {
  idTrabajador?: number;
  nombre: string;
  apellidoP: string;
  apellidoM: string;
  cargo: string;
  actividad: string;
  idContratista: number;
}

export interface DatosPersonales {
  trabajador?: number;
  idTrabajador?: number;
  numImss: string;
  direccion: string;
  curp: string;
  telefono: string;
}

export interface TrabajadorFormData {
  trabajador: Trabajador;
  datosPersonales: DatosPersonales;
}
