import sql from "mssql";
import "dotenv/config";

const config: sql.config = {
  server: process.env.DB_SERVER || "localhost",
  database: process.env.DB_NAME || "NombreDeTuBaseDeDatos",
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: false, // true si usas Azure SQL
    trustServerCertificate: true,
  },
};

// Pool de conexiones reutilizable en toda la app
export const poolPromise: Promise<sql.ConnectionPool> = new sql.ConnectionPool(config)
  .connect()
  .then((pool) => {
    console.log("Conectado a SQL Server");
    return pool;
  })
  .catch((err) => {
    console.error("Error de conexión a SQL Server:", err);
    throw err;
  });

export { sql };
