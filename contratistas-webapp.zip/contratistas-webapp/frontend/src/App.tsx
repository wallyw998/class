import React, { useState } from "react";
import ContratistaForm from "./components/ContratistaForm";
import TrabajadorForm from "./components/TrabajadorForm";
import ConsultaContratistas from "./components/ConsultaContratistas";
import ConsultaTrabajadores from "./components/ConsultaTrabajadores";

type PestanaPrincipal = "formulario" | "consulta";
type EntidadFormulario = "contratista" | "trabajador";
type EntidadConsulta = "contratistas" | "trabajadores";

export default function App() {
  const [pestanaPrincipal, setPestanaPrincipal] = useState<PestanaPrincipal>("formulario");
  const [entidadFormulario, setEntidadFormulario] = useState<EntidadFormulario>("contratista");
  const [entidadConsulta, setEntidadConsulta] = useState<EntidadConsulta>("contratistas");

  return (
    <div style={{ fontFamily: "system-ui, sans-serif" }}>
      {/* Pestañas principales */}
      <header style={estilos.header}>
        <h1 style={estilos.titulo}>Gestión de Contratistas</h1>
        <nav style={estilos.tabsPrincipales}>
          <button
            onClick={() => setPestanaPrincipal("formulario")}
            style={pestanaPrincipal === "formulario" ? estilos.tabActiva : estilos.tab}
          >
            Formulario
          </button>
          <button
            onClick={() => setPestanaPrincipal("consulta")}
            style={pestanaPrincipal === "consulta" ? estilos.tabActiva : estilos.tab}
          >
            Consulta de Datos
          </button>
        </nav>
      </header>

      {/* Contenido: Formulario */}
      {pestanaPrincipal === "formulario" && (
        <div>
          <div style={estilos.subTabs}>
            <button
              onClick={() => setEntidadFormulario("contratista")}
              style={entidadFormulario === "contratista" ? estilos.subTabActiva : estilos.subTab}
            >
              Contratistas
            </button>
            <button
              onClick={() => setEntidadFormulario("trabajador")}
              style={entidadFormulario === "trabajador" ? estilos.subTabActiva : estilos.subTab}
            >
              Trabajadores
            </button>
          </div>
          {entidadFormulario === "contratista" ? <ContratistaForm /> : <TrabajadorForm />}
        </div>
      )}

      {/* Contenido: Consulta */}
      {pestanaPrincipal === "consulta" && (
        <div>
          <div style={estilos.subTabs}>
            <button
              onClick={() => setEntidadConsulta("contratistas")}
              style={entidadConsulta === "contratistas" ? estilos.subTabActiva : estilos.subTab}
            >
              Contratistas
            </button>
            <button
              onClick={() => setEntidadConsulta("trabajadores")}
              style={entidadConsulta === "trabajadores" ? estilos.subTabActiva : estilos.subTab}
            >
              Trabajadores
            </button>
          </div>
          {entidadConsulta === "contratistas" ? <ConsultaContratistas /> : <ConsultaTrabajadores />}
        </div>
      )}
    </div>
  );
}

const estilos: Record<string, React.CSSProperties> = {
  header: { borderBottom: "1px solid #eee", padding: "16px 24px" },
  titulo: { fontSize: 20, margin: 0, marginBottom: 12 },
  tabsPrincipales: { display: "flex", gap: 8 },
  tab: {
    padding: "10px 20px", border: "1px solid #ccc", borderRadius: "8px 8px 0 0",
    background: "#f5f5f5", cursor: "pointer", fontSize: 14,
  },
  tabActiva: {
    padding: "10px 20px", border: "1px solid #2563eb", borderRadius: "8px 8px 0 0",
    background: "#2563eb", color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 600,
  },
  subTabs: { display: "flex", gap: 8, padding: "12px 24px 0" },
  subTab: {
    padding: "6px 14px", border: "1px solid #ddd", borderRadius: 6,
    background: "#fff", cursor: "pointer", fontSize: 13,
  },
  subTabActiva: {
    padding: "6px 14px", border: "1px solid #16a34a", borderRadius: 6,
    background: "#16a34a", color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600,
  },
};
