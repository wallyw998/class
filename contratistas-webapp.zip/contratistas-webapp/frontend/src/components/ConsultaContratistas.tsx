import React, { useEffect, useState } from "react";
import DataTable, { ColumnaTabla } from "./DataTable";
import { ContratistaFila } from "../types";
import { obtenerContratistas } from "../api";

const columnas: ColumnaTabla<ContratistaFila>[] = [
  { clave: "idContratistas", etiqueta: "Id" },
  { clave: "nombreComercial", etiqueta: "Nombre Comercial" },
  { clave: "camaraPatronal", etiqueta: "Cámara Patronal" },
  { clave: "actividadScian", etiqueta: "Actividad SCIAN" },
  { clave: "domicilio", etiqueta: "Domicilio" },
  { clave: "tipoEstablecimiento", etiqueta: "Tipo Establecimiento" },
  { clave: "nombre", etiqueta: "Contacto (Nombre)" },
  { clave: "apellido", etiqueta: "Contacto (Apellido)" },
  { clave: "telefono", etiqueta: "Teléfono" },
  { clave: "correo", etiqueta: "Correo" },
  { clave: "personalRegistrado", etiqueta: "Personal Registrado" },
  { clave: "solicitantesKCM", etiqueta: "Solicitantes KCM" },
  { clave: "razonSocial", etiqueta: "Razón Social" },
  { clave: "rfc", etiqueta: "RFC" },
  { clave: "primaRiesgo", etiqueta: "Prima de Riesgo" },
  { clave: "capitalContable", etiqueta: "Capital Contable" },
  { clave: "registroPatronal", etiqueta: "Registro Patronal" },
  { clave: "claseRiesgo", etiqueta: "Clase de Riesgo" },
  { clave: "areaTrabajo", etiqueta: "Área de Trabajo" },
  { clave: "diasLaborados", etiqueta: "Días Laborados" },
];

export default function ConsultaContratistas() {
  const [filas, setFilas] = useState<ContratistaFila[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function cargarDatos() {
    setCargando(true);
    setError(null);
    try {
      const datos = await obtenerContratistas();
      setFilas(datos);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al cargar contratistas.");
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => {
    cargarDatos();
  }, []);

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <h2 style={{ fontSize: 18 }}>Consulta de Contratistas</h2>
        <button onClick={cargarDatos} style={estiloBoton}>
          Actualizar
        </button>
      </div>
      {error && <p style={{ color: "#dc2626" }}>{error}</p>}
      <DataTable
        columnas={columnas}
        filas={filas}
        cargando={cargando}
        claveFila="idContratistas"
      />
    </div>
  );
}

const estiloBoton: React.CSSProperties = {
  padding: "6px 14px",
  background: "#2563eb",
  color: "#fff",
  border: "none",
  borderRadius: 6,
  cursor: "pointer",
  fontSize: 13,
};
