import React, { useMemo, useState } from "react";

export interface ColumnaTabla<T> {
  clave: keyof T;
  etiqueta: string;
}

interface DataTableProps<T> {
  columnas: ColumnaTabla<T>[];
  filas: T[];
  cargando?: boolean;
  claveFila: keyof T; // columna a usar como key de React (ej. idContratistas)
}

// Tabla genérica: filtra en el cliente por cada columna a partir de lo ya cargado.
// Cada input de búsqueda filtra únicamente su propia columna (coincidencia parcial, sin distinguir mayúsculas).
export default function DataTable<T extends Record<string, any>>({
  columnas,
  filas,
  cargando,
  claveFila,
}: DataTableProps<T>) {
  const [filtros, setFiltros] = useState<Record<string, string>>({});

  function actualizarFiltro(clave: string, valor: string) {
    setFiltros((prev) => ({ ...prev, [clave]: valor }));
  }

  const filasFiltradas = useMemo(() => {
    return filas.filter((fila) =>
      columnas.every((col) => {
        const valorFiltro = filtros[col.clave as string];
        if (!valorFiltro) return true;
        const valorCelda = fila[col.clave];
        return String(valorCelda ?? "")
          .toLowerCase()
          .includes(valorFiltro.toLowerCase());
      })
    );
  }, [filas, filtros, columnas]);

  return (
    <div style={estilos.contenedorTabla}>
      <table style={estilos.tabla}>
        <thead>
          <tr>
            {columnas.map((col) => (
              <th key={String(col.clave)} style={estilos.encabezado}>
                {col.etiqueta}
              </th>
            ))}
          </tr>
          <tr>
            {columnas.map((col) => (
              <th key={`buscador-${String(col.clave)}`} style={estilos.celdaBuscador}>
                <input
                  type="text"
                  placeholder="Buscar..."
                  value={filtros[col.clave as string] || ""}
                  onChange={(e) => actualizarFiltro(col.clave as string, e.target.value)}
                  style={estilos.inputBuscador}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {cargando && (
            <tr>
              <td colSpan={columnas.length} style={estilos.celdaVacia}>
                Cargando...
              </td>
            </tr>
          )}

          {!cargando && filasFiltradas.length === 0 && (
            <tr>
              <td colSpan={columnas.length} style={estilos.celdaVacia}>
                No se encontraron resultados.
              </td>
            </tr>
          )}

          {!cargando &&
            filasFiltradas.map((fila) => (
              <tr key={String(fila[claveFila])}>
                {columnas.map((col) => (
                  <td key={String(col.clave)} style={estilos.celda}>
                    {fila[col.clave] ?? ""}
                  </td>
                ))}
              </tr>
            ))}
        </tbody>
      </table>
      <p style={estilos.contador}>
        {filasFiltradas.length} de {filas.length} registro(s)
      </p>
    </div>
  );
}

const estilos: Record<string, React.CSSProperties> = {
  contenedorTabla: { overflowX: "auto", width: "100%" },
  tabla: { borderCollapse: "collapse", width: "100%", fontSize: 13 },
  encabezado: {
    background: "#1f2937",
    color: "#fff",
    padding: "8px 10px",
    textAlign: "left",
    whiteSpace: "nowrap",
    position: "sticky",
    top: 0,
  },
  celdaBuscador: { background: "#f3f4f6", padding: 4, borderBottom: "1px solid #ddd" },
  inputBuscador: {
    width: "100%",
    boxSizing: "border-box",
    padding: "4px 6px",
    fontSize: 12,
    border: "1px solid #ccc",
    borderRadius: 4,
  },
  celda: { padding: "6px 10px", borderBottom: "1px solid #eee", whiteSpace: "nowrap" },
  celdaVacia: { padding: 16, textAlign: "center", color: "#888" },
  contador: { fontSize: 12, color: "#666", marginTop: 8 },
};
