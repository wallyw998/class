import React, { useEffect, useState } from "react";
import DataTable, { ColumnaTabla } from "./DataTable";
import { TrabajadorFila } from "../types";
import { obtenerTrabajadores } from "../api";

const columnas: ColumnaTabla<TrabajadorFila>[] = [
  { clave: "idTrabajador", etiqueta: "Id" },
  { clave: "nombre", etiqueta: "Nombre" },
  { clave: "apellidoP", etiqueta: "Apellido Paterno" },
  { clave: "apellidoM", etiqueta: "Apellido Materno" },
  { clave: "cargo", etiqueta: "Cargo" },
  { clave: "actividad", etiqueta: "Actividad" },
  { clave: "idContratista", etiqueta: "Id Contratista" },
  { clave: "numImss", etiqueta: "Núm. IMSS" },
  { clave: "direccion", etiqueta: "Dirección" },
  { clave: "curp", etiqueta: "CURP" },
  { clave: "telefono", etiqueta: "Teléfono" },
];

export default function ConsultaTrabajadores() {
  const [filas, setFilas] = useState<TrabajadorFila[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function cargarDatos() {
    setCargando(true);
    setError(null);
    try {
      const datos = await obtenerTrabajadores();
      setFilas(datos);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al cargar trabajadores.");
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => {
    cargarDatos();
  }, []);

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <h2 style={{ fontSize: 18 }}>Consulta de Trabajadores</h2>
        <button onClick={cargarDatos} style={estiloBoton}>
          Actualizar
        </button>
      </div>
      {error && <p style={{ color: "#dc2626" }}>{error}</p>}
      <DataTable
        columnas={columnas}
        filas={filas}
        cargando={cargando}
        claveFila="idTrabajador"
      />
    </div>
  );
}

const estiloBoton: React.CSSProperties = {
  padding: "6px 14px",
  background: "#2563eb",
  color: "#fff",
  border: "none",
  borderRadius: 6,
  cursor: "pointer",
  fontSize: 13,
};
