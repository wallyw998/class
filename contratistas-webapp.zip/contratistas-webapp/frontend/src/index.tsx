import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

const contenedor = document.getElementById("root");
if (contenedor) {
  ReactDOM.createRoot(contenedor).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}
