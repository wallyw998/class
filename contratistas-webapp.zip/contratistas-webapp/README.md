# Aplicación Web de Contratistas — Formulario + Consulta

Stack: **HTML + TypeScript + React (TSX) + Node.js + JavaScript**.
(El backend en C# del entregable anterior sigue funcionando igual si prefieres usarlo en vez de Node — expone las mismas rutas `/api/contratistas` y `/api/trabajadores`.)

## Qué incluye

Una sola aplicación con **dos pestañas principales**:

1. **Formulario** — captura datos de Contratistas (4 tablas) o Trabajadores (2 tablas).
2. **Consulta de Datos** — tabla con todos los registros, con **una barra de búsqueda por cada columna** que filtra en tiempo real.

Dentro de cada pestaña hay un selector para elegir entre **Contratistas** y **Trabajadores**.

## Estructura

```
contratistas-webapp/
├── frontend/                       # HTML + TSX + TypeScript + React
│   ├── index.html
│   ├── src/
│   │   ├── types.ts
│   │   ├── api.ts                  # fetch hacia el backend Node.js
│   │   ├── App.tsx                 # pestañas: Formulario | Consulta
│   │   ├── index.tsx
│   │   └── components/
│   │       ├── ContratistaForm.tsx
│   │       ├── TrabajadorForm.tsx
│   │       ├── ConsultaContratistas.tsx   # tabla + buscadores
│   │       ├── ConsultaTrabajadores.tsx   # tabla + buscadores
│   │       └── DataTable.tsx              # tabla genérica reutilizable
│   └── package.json
│
└── backend/                        # Node.js + Express + TypeScript
    ├── src/
    │   ├── types.ts
    │   ├── db.ts                   # conexión a SQL Server (mssql)
    │   ├── server.ts
    │   └── routes/
    │       ├── contratistas.ts     # GET (con filtros por columna), POST
    │       └── trabajadores.ts     # GET (con filtros por columna), POST
    ├── package.json
    └── .env.example
```

## Cómo correrlo

### Backend (Node.js)
1. Copia `backend/.env.example` a `backend/.env` y ajusta los datos de conexión a tu SQL Server
   (la misma base donde ejecutaste los scripts de las 6 tablas).
2. Desde `backend/`:
   ```
   npm install
   npm run dev
   ```
3. La API queda en `http://localhost:4000/api/...`.

### Frontend (React + TSX)
1. Desde `frontend/`:
   ```
   npm install
   npm run dev
   ```
2. Abre `http://localhost:5173`.

## Cómo funciona la búsqueda por columna

- La pestaña **Consulta de Datos** carga todos los registros desde la API y los muestra en una tabla.
- Debajo de cada encabezado de columna hay un campo de texto: escribir ahí filtra **solo esa columna**
  (coincidencia parcial, sin distinguir mayúsculas/minúsculas), combinándose con los demás filtros activos.
- El filtrado es del lado del cliente sobre los datos ya cargados (rápido y sin recargar la página).
  El backend también soporta filtros por query string (`?nombreComercial=...&rfc=...`) por si más adelante
  quieres mover el filtrado al servidor para catálogos muy grandes.
