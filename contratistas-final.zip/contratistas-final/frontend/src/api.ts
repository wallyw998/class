import {
  ContratistaFormData,
  ContratistaFila,
  TrabajadorFormData,
  TrabajadorFila,
} from "./types";

// Backend en C#/.NET. Ajusta el puerto al que muestre "dotnet run"
// (revisa la consola al iniciar la API — típicamente https://localhost:7000 o similar).
const API_BASE_URL = "https://localhost:7000/api";

async function manejarRespuesta<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const texto = await res.text();
    throw new Error(texto || `Error ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export async function crearContratista(data: ContratistaFormData) {
  const res = await fetch(`${API_BASE_URL}/contratistas`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return manejarRespuesta<{ idContratistas: number }>(res);
}

export async function obtenerContratistas(
  filtros: Record<string, string> = {}
): Promise<ContratistaFila[]> {
  const query = new URLSearchParams(
    Object.entries(filtros).filter(([, v]) => v.trim() !== "")
  ).toString();
  const res = await fetch(`${API_BASE_URL}/contratistas${query ? `?${query}` : ""}`);
  return manejarRespuesta<ContratistaFila[]>(res);
}

export async function crearTrabajador(data: TrabajadorFormData) {
  const res = await fetch(`${API_BASE_URL}/trabajadores`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return manejarRespuesta<{ idTrabajador: number }>(res);
}

export async function obtenerTrabajadores(
  filtros: Record<string, string> = {}
): Promise<TrabajadorFila[]> {
  const query = new URLSearchParams(
    Object.entries(filtros).filter(([, v]) => v.trim() !== "")
  ).toString();
  const res = await fetch(`${API_BASE_URL}/trabajadores${query ? `?${query}` : ""}`);
  return manejarRespuesta<TrabajadorFila[]>(res);
}
