import React, { useEffect, useState } from "react";
import DataTable, { ColumnaTabla } from "./DataTable";
import { TrabajadorFila } from "../types";
import { obtenerTrabajadores } from "../api";
import "../styles/Tabla.css";

const columnas: ColumnaTabla<TrabajadorFila>[] = [
  { clave: "idTrabajador", etiqueta: "Id" },
  { clave: "nombre", etiqueta: "Nombre" },
  { clave: "apellidoP", etiqueta: "Apellido Paterno" },
  { clave: "apellidoM", etiqueta: "Apellido Materno" },
  { clave: "cargo", etiqueta: "Cargo" },
  { clave: "actividad", etiqueta: "Actividad" },
  { clave: "idContratista", etiqueta: "Id Contratista" },
  { clave: "numImss", etiqueta: "Núm. IMSS" },
  { clave: "direccion", etiqueta: "Dirección" },
  { clave: "curp", etiqueta: "CURP" },
  { clave: "telefono", etiqueta: "Teléfono" },
];

export default function ConsultaTrabajadores() {
  const [filas, setFilas] = useState<TrabajadorFila[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function cargarDatos() {
    setCargando(true);
    setError(null);
    try {
      setFilas(await obtenerTrabajadores());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al cargar trabajadores.");
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => {
    cargarDatos();
  }, []);

  return (
    <div className="consulta-contenedor">
      <div className="consulta-encabezado">
        <h2 className="consulta-titulo">Consulta de Trabajadores</h2>
        <button className="boton-actualizar" onClick={cargarDatos}>
          Actualizar
        </button>
      </div>
      {error && <p className="mensaje-error">{error}</p>}
      <DataTable columnas={columnas} filas={filas} cargando={cargando} claveFila="idTrabajador" />
    </div>
  );
}
