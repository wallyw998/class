import React, { useMemo, useState } from "react";
import "../styles/Tabla.css";

export interface ColumnaTabla<T> {
  clave: keyof T;
  etiqueta: string;
}

interface DataTableProps<T> {
  columnas: ColumnaTabla<T>[];
  filas: T[];
  cargando?: boolean;
  claveFila: keyof T;
}

export default function DataTable<T extends Record<string, any>>({
  columnas,
  filas,
  cargando,
  claveFila,
}: DataTableProps<T>) {
  const [filtros, setFiltros] = useState<Record<string, string>>({});

  function actualizarFiltro(clave: string, valor: string) {
    setFiltros((prev) => ({ ...prev, [clave]: valor }));
  }

  const filasFiltradas = useMemo(() => {
    return filas.filter((fila) =>
      columnas.every((col) => {
        const valorFiltro = filtros[col.clave as string];
        if (!valorFiltro) return true;
        const valorCelda = fila[col.clave];
        return String(valorCelda ?? "")
          .toLowerCase()
          .includes(valorFiltro.toLowerCase());
      })
    );
  }, [filas, filtros, columnas]);

  return (
    <div className="tabla-contenedor">
      <table className="tabla-datos">
        <thead>
          <tr>
            {columnas.map((col) => (
              <th key={String(col.clave)}>{col.etiqueta}</th>
            ))}
          </tr>
          <tr className="fila-buscadores">
            {columnas.map((col) => (
              <th key={`buscador-${String(col.clave)}`}>
                <input
                  type="text"
                  placeholder="Buscar..."
                  value={filtros[col.clave as string] || ""}
                  onChange={(e) => actualizarFiltro(col.clave as string, e.target.value)}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {cargando && (
            <tr>
              <td colSpan={columnas.length} className="tabla-celda-vacia">
                Cargando...
              </td>
            </tr>
          )}

          {!cargando && filasFiltradas.length === 0 && (
            <tr>
              <td colSpan={columnas.length} className="tabla-celda-vacia">
                No se encontraron resultados.
              </td>
            </tr>
          )}

          {!cargando &&
            filasFiltradas.map((fila) => (
              <tr key={String(fila[claveFila])}>
                {columnas.map((col) => (
                  <td key={String(col.clave)}>{fila[col.clave] ?? ""}</td>
                ))}
              </tr>
            ))}
        </tbody>
      </table>
      <p className="tabla-contador">
        {filasFiltradas.length} de {filas.length} registro(s)
      </p>
    </div>
  );
}
