import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/global.css";

const contenedor = document.getElementById("root");
if (contenedor) {
  ReactDOM.createRoot(contenedor).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}
