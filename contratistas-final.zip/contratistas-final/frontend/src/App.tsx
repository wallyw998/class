import React, { useState } from "react";
import ContratistaForm from "./components/ContratistaForm";
import TrabajadorForm from "./components/TrabajadorForm";
import ConsultaContratistas from "./components/ConsultaContratistas";
import ConsultaTrabajadores from "./components/ConsultaTrabajadores";
import "./styles/App.css";

type PestanaPrincipal = "formulario" | "consulta";
type EntidadFormulario = "contratista" | "trabajador";
type EntidadConsulta = "contratistas" | "trabajadores";

export default function App() {
  const [pestanaPrincipal, setPestanaPrincipal] = useState<PestanaPrincipal>("formulario");
  const [entidadFormulario, setEntidadFormulario] = useState<EntidadFormulario>("contratista");
  const [entidadConsulta, setEntidadConsulta] = useState<EntidadConsulta>("contratistas");

  return (
    <div>
      <header className="app-header">
        <h1 className="app-titulo">Gestión de Contratistas</h1>
        <nav className="tabs-principales">
          <button
            className={pestanaPrincipal === "formulario" ? "tab-activa" : "tab"}
            onClick={() => setPestanaPrincipal("formulario")}
          >
            Formulario
          </button>
          <button
            className={pestanaPrincipal === "consulta" ? "tab-activa" : "tab"}
            onClick={() => setPestanaPrincipal("consulta")}
          >
            Consulta de Datos
          </button>
        </nav>
      </header>

      {pestanaPrincipal === "formulario" && (
        <div>
          <div className="sub-tabs">
            <button
              className={entidadFormulario === "contratista" ? "sub-tab-activa" : "sub-tab"}
              onClick={() => setEntidadFormulario("contratista")}
            >
              Contratistas
            </button>
            <button
              className={entidadFormulario === "trabajador" ? "sub-tab-activa" : "sub-tab"}
              onClick={() => setEntidadFormulario("trabajador")}
            >
              Trabajadores
            </button>
          </div>
          {entidadFormulario === "contratista" ? <ContratistaForm /> : <TrabajadorForm />}
        </div>
      )}

      {pestanaPrincipal === "consulta" && (
        <div>
          <div className="sub-tabs">
            <button
              className={entidadConsulta === "contratistas" ? "sub-tab-activa" : "sub-tab"}
              onClick={() => setEntidadConsulta("contratistas")}
            >
              Contratistas
            </button>
            <button
              className={entidadConsulta === "trabajadores" ? "sub-tab-activa" : "sub-tab"}
              onClick={() => setEntidadConsulta("trabajadores")}
            >
              Trabajadores
            </button>
          </div>
          {entidadConsulta === "contratistas" ? <ConsultaContratistas /> : <ConsultaTrabajadores />}
        </div>
      )}
    </div>
  );
}
