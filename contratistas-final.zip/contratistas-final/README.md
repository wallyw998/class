# Gestión de Contratistas — Aplicación Web

Stack: **HTML · CSS · JavaScript · TypeScript · React · TSQL · C# · .NET · Node.js**

- **TSQL** — script de las 6 tablas en SQL Server (carpeta `database/`).
- **C# / .NET** — backend (API REST) que conecta con SQL Server vía Entity Framework Core.
- **React + TypeScript (TSX) + HTML + CSS** — frontend con dos pestañas: **Formulario** y **Consulta de Datos**.
- **Node.js** — solo se usa como herramienta para correr y compilar el frontend (`npm`, Vite). No es un backend en este proyecto.

## Estructura

```
contratistas-final/
├── database/
│   └── 01_crear_tablas.sql       # Script TSQL de las 6 tablas
│
├── backend/                       # C# / .NET — API REST
│   ├── Models/                    # Una clase por tabla + DTOs
│   ├── Data/ContratistasDbContext.cs
│   ├── Controllers/
│   │   ├── ContratistasController.cs   # GET (filtros por columna) / POST
│   │   └── TrabajadoresController.cs   # GET (filtros por columna) / POST
│   ├── Program.cs
│   ├── appsettings.json
│   └── ContratistasApi.csproj
│
└── frontend/                      # React + TypeScript + HTML + CSS (Node solo para tooling)
    ├── index.html
    ├── src/
    │   ├── types.ts
    │   ├── api.ts                 # fetch hacia la API en C#/.NET
    │   ├── App.tsx                # pestañas: Formulario | Consulta
    │   ├── index.tsx
    │   ├── styles/                # CSS separado por sección
    │   │   ├── global.css
    │   │   ├── App.css
    │   │   ├── Formulario.css
    │   │   └── Tabla.css
    │   └── components/
    │       ├── ContratistaForm.tsx
    │       ├── TrabajadorForm.tsx
    │       ├── ConsultaContratistas.tsx
    │       ├── ConsultaTrabajadores.tsx
    │       └── DataTable.tsx      # tabla genérica con buscador por columna
    └── package.json
```

## Cómo correrlo

### 1. Base de datos
Ejecuta `database/01_crear_tablas.sql` en SSMS sobre tu base de datos.

### 2. Backend (C#/.NET)
1. Ajusta `backend/appsettings.json` con tu cadena de conexión a SQL Server.
2. Desde `backend/`:
   ```
   dotnet restore
   dotnet run
   ```
3. Anota el puerto que muestre la consola (ej. `https://localhost:7000`). Si es distinto, ajústalo en `frontend/src/api.ts`.

### 3. Frontend (React, corrido con Node)
1. Desde `frontend/`:
   ```
   npm install
   npm run dev
   ```
2. Abre `http://localhost:5173`.

## Funcionalidad

- **Pestaña Formulario**: registra Contratistas (4 tablas) o Trabajadores (2 tablas), con validación de campos obligatorios.
- **Pestaña Consulta de Datos**: tabla con todos los registros; debajo de cada encabezado de columna hay un campo de búsqueda independiente que filtra esa columna en tiempo real.
