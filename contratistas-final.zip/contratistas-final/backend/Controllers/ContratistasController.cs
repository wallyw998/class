using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContratistasApi.Data;
using ContratistasApi.Models;

namespace ContratistasApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContratistasController : ControllerBase
    {
        private readonly ContratistasDbContext _context;

        private static readonly string[] ColumnasBuscables =
        {
            "nombreComercial", "camaraPatronal", "actividadScian", "domicilio",
            "tipoEstablecimiento", "nombre", "apellido", "telefono", "correo", "solicitantesKCM"
        };

        public ContratistasController(ContratistasDbContext context)
        {
            _context = context;
        }

        // GET: api/contratistas?nombreComercial=abc&rfc=xyz&claseRiesgo=...
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ContratistaFilaDto>>> ObtenerTodos()
        {
            var query = _context.Contratistas
                .Include(c => c.DatosContables)
                .Include(c => c.DatosSeguro)
                .Include(c => c.Actividades)
                .AsQueryable();

            foreach (var columna in ColumnasBuscables)
            {
                if (Request.Query.TryGetValue(columna, out var valor) && !string.IsNullOrWhiteSpace(valor))
                {
                    var texto = valor.ToString();
                    query = columna switch
                    {
                        "nombreComercial" => query.Where(c => c.NombreComercial.Contains(texto)),
                        "camaraPatronal" => query.Where(c => c.CamaraPatronal.Contains(texto)),
                        "actividadScian" => query.Where(c => c.ActividadScian.Contains(texto)),
                        "domicilio" => query.Where(c => c.Domicilio != null && c.Domicilio.Contains(texto)),
                        "tipoEstablecimiento" => query.Where(c => c.TipoEstablecimiento.Contains(texto)),
                        "nombre" => query.Where(c => c.Nombre != null && c.Nombre.Contains(texto)),
                        "apellido" => query.Where(c => c.Apellido != null && c.Apellido.Contains(texto)),
                        "telefono" => query.Where(c => c.Telefono != null && c.Telefono.Contains(texto)),
                        "correo" => query.Where(c => c.Correo != null && c.Correo.Contains(texto)),
                        "solicitantesKCM" => query.Where(c => c.SolicitantesKCM.Contains(texto)),
                        _ => query,
                    };
                }
            }

            if (Request.Query.TryGetValue("rfc", out var rfc) && !string.IsNullOrWhiteSpace(rfc))
                query = query.Where(c => c.DatosContables != null && c.DatosContables.RFC != null && c.DatosContables.RFC.Contains(rfc.ToString()));

            if (Request.Query.TryGetValue("razonSocial", out var razonSocial) && !string.IsNullOrWhiteSpace(razonSocial))
                query = query.Where(c => c.DatosContables != null && c.DatosContables.RazonSocial != null && c.DatosContables.RazonSocial.Contains(razonSocial.ToString()));

            if (Request.Query.TryGetValue("claseRiesgo", out var claseRiesgo) && !string.IsNullOrWhiteSpace(claseRiesgo))
                query = query.Where(c => c.DatosSeguro != null && c.DatosSeguro.ClaseRiesgo.Contains(claseRiesgo.ToString()));

            var resultado = await query
                .OrderByDescending(c => c.IdContratistas)
                .Select(c => new ContratistaFilaDto
                {
                    IdContratistas = c.IdContratistas,
                    NombreComercial = c.NombreComercial,
                    CamaraPatronal = c.CamaraPatronal,
                    ActividadScian = c.ActividadScian,
                    Domicilio = c.Domicilio,
                    TipoEstablecimiento = c.TipoEstablecimiento,
                    Nombre = c.Nombre,
                    Apellido = c.Apellido,
                    Telefono = c.Telefono,
                    Correo = c.Correo,
                    PersonalRegistrado = c.PersonalRegistrado,
                    SolicitantesKCM = c.SolicitantesKCM,
                    RazonSocial = c.DatosContables != null ? c.DatosContables.RazonSocial : null,
                    RFC = c.DatosContables != null ? c.DatosContables.RFC : null,
                    PrimaRiesgo = c.DatosContables != null ? c.DatosContables.PrimaRiesgo : (decimal?)null,
                    CapitalContable = c.DatosContables != null ? c.DatosContables.CapitalContable : null,
                    RegistroPatronal = c.DatosSeguro != null ? c.DatosSeguro.RegistroPatronal : null,
                    ClaseRiesgo = c.DatosSeguro != null ? c.DatosSeguro.ClaseRiesgo : null,
                    AreaTrabajo = c.Actividades != null ? c.Actividades.AreaTrabajo : null,
                    DiasLaborados = c.Actividades != null ? c.Actividades.DiasLaborados : null,
                })
                .ToListAsync();

            return Ok(resultado);
        }

        // GET: api/contratistas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Contratista>> ObtenerPorId(int id)
        {
            var contratista = await _context.Contratistas
                .Include(c => c.DatosContables)
                .Include(c => c.DatosSeguro)
                .Include(c => c.Actividades)
                .FirstOrDefaultAsync(c => c.IdContratistas == id);

            if (contratista == null) return NotFound();
            return Ok(contratista);
        }

        // POST: api/contratistas — guarda las 4 tablas en una sola transacción
        [HttpPost]
        public async Task<ActionResult<Contratista>> Crear([FromBody] ContratistaFormDto formulario)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            using var transaccion = await _context.Database.BeginTransactionAsync();
            try
            {
                var contratista = formulario.Datos;
                _context.Contratistas.Add(contratista);
                await _context.SaveChangesAsync();

                formulario.Contables.IdContratistas = contratista.IdContratistas;
                formulario.Seguro.IdContratistas = contratista.IdContratistas;
                formulario.Actividades.IdContratistas = contratista.IdContratistas;

                _context.DatosContables.Add(formulario.Contables);
                _context.DatosSeguro.Add(formulario.Seguro);
                _context.Actividades.Add(formulario.Actividades);

                await _context.SaveChangesAsync();
                await transaccion.CommitAsync();

                return CreatedAtAction(nameof(ObtenerPorId), new { id = contratista.IdContratistas }, contratista);
            }
            catch (Exception ex)
            {
                await transaccion.RollbackAsync();
                return StatusCode(500, $"Error al guardar el contratista: {ex.Message}");
            }
        }
    }
}
