using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContratistasApi.Data;
using ContratistasApi.Models;

namespace ContratistasApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TrabajadoresController : ControllerBase
    {
        private readonly ContratistasDbContext _context;

        private static readonly string[] ColumnasBuscables =
        {
            "nombre", "apellidoP", "apellidoM", "cargo", "actividad"
        };

        public TrabajadoresController(ContratistasDbContext context)
        {
            _context = context;
        }

        // GET: api/trabajadores?nombre=juan&cargo=soldador&curp=...
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TrabajadorFilaDto>>> ObtenerTodos()
        {
            var query = _context.Trabajadores
                .Include(t => t.DatosPersonales)
                .AsQueryable();

            foreach (var columna in ColumnasBuscables)
            {
                if (Request.Query.TryGetValue(columna, out var valor) && !string.IsNullOrWhiteSpace(valor))
                {
                    var texto = valor.ToString();
                    query = columna switch
                    {
                        "nombre" => query.Where(t => t.Nombre.Contains(texto)),
                        "apellidoP" => query.Where(t => t.ApellidoP.Contains(texto)),
                        "apellidoM" => query.Where(t => t.ApellidoM != null && t.ApellidoM.Contains(texto)),
                        "cargo" => query.Where(t => t.Cargo != null && t.Cargo.Contains(texto)),
                        "actividad" => query.Where(t => t.Actividad != null && t.Actividad.Contains(texto)),
                        _ => query,
                    };
                }
            }

            if (Request.Query.TryGetValue("curp", out var curp) && !string.IsNullOrWhiteSpace(curp))
                query = query.Where(t => t.DatosPersonales != null && t.DatosPersonales.CURP != null && t.DatosPersonales.CURP.Contains(curp.ToString()));

            if (Request.Query.TryGetValue("telefono", out var telefono) && !string.IsNullOrWhiteSpace(telefono))
                query = query.Where(t => t.DatosPersonales != null && t.DatosPersonales.Telefono != null && t.DatosPersonales.Telefono.Contains(telefono.ToString()));

            var resultado = await query
                .OrderByDescending(t => t.IdTrabajador)
                .Select(t => new TrabajadorFilaDto
                {
                    IdTrabajador = t.IdTrabajador,
                    Nombre = t.Nombre,
                    ApellidoP = t.ApellidoP,
                    ApellidoM = t.ApellidoM,
                    Cargo = t.Cargo,
                    Actividad = t.Actividad,
                    IdContratista = t.IdContratista,
                    NumImss = t.DatosPersonales != null ? t.DatosPersonales.NumImss : null,
                    Direccion = t.DatosPersonales != null ? t.DatosPersonales.Direccion : null,
                    CURP = t.DatosPersonales != null ? t.DatosPersonales.CURP : null,
                    Telefono = t.DatosPersonales != null ? t.DatosPersonales.Telefono : null,
                })
                .ToListAsync();

            return Ok(resultado);
        }

        // GET: api/trabajadores/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Trabajador>> ObtenerPorId(int id)
        {
            var trabajador = await _context.Trabajadores
                .Include(t => t.DatosPersonales)
                .FirstOrDefaultAsync(t => t.IdTrabajador == id);

            if (trabajador == null) return NotFound();
            return Ok(trabajador);
        }

        // POST: api/trabajadores
        [HttpPost]
        public async Task<ActionResult<Trabajador>> Crear([FromBody] TrabajadorFormDto formulario)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var existeContratista = await _context.Contratistas
                .AnyAsync(c => c.IdContratistas == formulario.Trabajador.IdContratista);

            if (!existeContratista)
                return BadRequest($"No existe un contratista con Id {formulario.Trabajador.IdContratista}.");

            using var transaccion = await _context.Database.BeginTransactionAsync();
            try
            {
                var trabajador = formulario.Trabajador;
                _context.Trabajadores.Add(trabajador);
                await _context.SaveChangesAsync();

                formulario.DatosPersonales.IdTrabajador = trabajador.IdTrabajador;
                _context.DatosPersonales.Add(formulario.DatosPersonales);

                await _context.SaveChangesAsync();
                await transaccion.CommitAsync();

                return CreatedAtAction(nameof(ObtenerPorId), new { id = trabajador.IdTrabajador }, trabajador);
            }
            catch (Exception ex)
            {
                await transaccion.RollbackAsync();
                return StatusCode(500, $"Error al guardar el trabajador: {ex.Message}");
            }
        }
    }
}
