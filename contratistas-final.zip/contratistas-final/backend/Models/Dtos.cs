namespace ContratistasApi.Models
{
    // ---- DTOs de entrada (lo que envían los formularios) ----

    public class ContratistaFormDto
    {
        public Contratista Datos { get; set; } = new();
        public DatosContables Contables { get; set; } = new();
        public DatosSeguro Seguro { get; set; } = new();
        public Actividades Actividades { get; set; } = new();
    }

    public class TrabajadorFormDto
    {
        public Trabajador Trabajador { get; set; } = new();
        public DatosPersonales DatosPersonales { get; set; } = new();
    }

    // ---- DTOs de salida (lo que consume la tabla de consulta) ----

    public class ContratistaFilaDto
    {
        public int IdContratistas { get; set; }
        public string? NombreComercial { get; set; }
        public string? CamaraPatronal { get; set; }
        public string? ActividadScian { get; set; }
        public string? Domicilio { get; set; }
        public string? TipoEstablecimiento { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public string? Telefono { get; set; }
        public string? Correo { get; set; }
        public int? PersonalRegistrado { get; set; }
        public string? SolicitantesKCM { get; set; }
        public string? RazonSocial { get; set; }
        public string? RFC { get; set; }
        public decimal? PrimaRiesgo { get; set; }
        public decimal? CapitalContable { get; set; }
        public string? RegistroPatronal { get; set; }
        public string? ClaseRiesgo { get; set; }
        public string? AreaTrabajo { get; set; }
        public string? DiasLaborados { get; set; }
    }

    public class TrabajadorFilaDto
    {
        public int IdTrabajador { get; set; }
        public string? Nombre { get; set; }
        public string? ApellidoP { get; set; }
        public string? ApellidoM { get; set; }
        public string? Cargo { get; set; }
        public string? Actividad { get; set; }
        public int IdContratista { get; set; }
        public string? NumImss { get; set; }
        public string? Direccion { get; set; }
        public string? CURP { get; set; }
        public string? Telefono { get; set; }
    }
}
