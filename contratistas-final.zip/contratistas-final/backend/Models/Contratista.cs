using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ContratistasApi.Models
{
    // Tabla: Cntr_Datos
    public class Contratista
    {
        [Key]
        public int IdContratistas { get; set; }

        [Required, MaxLength(150)]
        public string NombreComercial { get; set; } = string.Empty;

        [Required, MaxLength(150)]
        public string CamaraPatronal { get; set; } = string.Empty;

        [Required, MaxLength(150)]
        public string ActividadScian { get; set; } = string.Empty;

        [MaxLength(250)]
        public string? Domicilio { get; set; }

        [Required, MaxLength(100)]
        public string TipoEstablecimiento { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? Nombre { get; set; }

        [MaxLength(100)]
        public string? Apellido { get; set; }

        [MaxLength(20)]
        public string? Telefono { get; set; }

        [MaxLength(150), EmailAddress]
        public string? Correo { get; set; }

        public int? PersonalRegistrado { get; set; }

        [Required, MaxLength(150)]
        public string SolicitantesKCM { get; set; } = string.Empty;

        [JsonIgnore]
        public DatosContables? DatosContables { get; set; }
        [JsonIgnore]
        public DatosSeguro? DatosSeguro { get; set; }
        [JsonIgnore]
        public Actividades? Actividades { get; set; }
    }

    // Tabla: Cntr_Datos_Contables
    public class DatosContables
    {
        [Key]
        public int IdDatosContables { get; set; }

        [MaxLength(150)]
        public string? RazonSocial { get; set; }

        [MaxLength(13)]
        public string? RFC { get; set; }

        [MaxLength(250)]
        public string? DomicilioFiscal { get; set; }

        [Required]
        [Column(TypeName = "decimal(5,2)")]
        public decimal PrimaRiesgo { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CapitalContable { get; set; }

        [Required]
        public int IdContratistas { get; set; }

        [ForeignKey(nameof(IdContratistas)), JsonIgnore]
        public Contratista? Contratista { get; set; }
    }

    // Tabla: Cntr_Datos_Seguro
    public class DatosSeguro
    {
        [Key]
        public int IdDatosSeguro { get; set; }

        [MaxLength(50)]
        public string? RegistroPatronal { get; set; }

        [MaxLength(150)]
        public string? ActividadImss { get; set; }

        [Required, MaxLength(50)]
        public string ClaseRiesgo { get; set; } = string.Empty;

        [Required]
        public int IdContratistas { get; set; }

        [ForeignKey(nameof(IdContratistas)), JsonIgnore]
        public Contratista? Contratista { get; set; }
    }

    // Tabla: Cntr_Actividades
    public class Actividades
    {
        [Key]
        public int IdActividades { get; set; }

        [MaxLength(150)]
        public string? AccesoPlanta { get; set; }

        [MaxLength(150)]
        public string? DimensionesCons { get; set; }

        [MaxLength(250)]
        [Column("Actividades")]
        public string? ActividadesTexto { get; set; }

        [MaxLength(150)]
        public string? AreaTrabajo { get; set; }

        [MaxLength(250)]
        public string? ActividadesEnPlanta { get; set; }

        [MaxLength(100)]
        public string? DiasLaborados { get; set; }

        [Required]
        public int IdContratistas { get; set; }

        [ForeignKey(nameof(IdContratistas)), JsonIgnore]
        public Contratista? Contratista { get; set; }
    }
}
