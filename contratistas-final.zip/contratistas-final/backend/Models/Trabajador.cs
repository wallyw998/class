using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ContratistasApi.Models
{
    // Tabla: Cntr_Trabajador
    public class Trabajador
    {
        [Key]
        public int IdTrabajador { get; set; }

        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string ApellidoP { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? ApellidoM { get; set; }

        [MaxLength(100)]
        public string? Cargo { get; set; }

        [MaxLength(200)]
        public string? Actividad { get; set; }

        [Required]
        public int IdContratista { get; set; }

        [JsonIgnore]
        public DatosPersonales? DatosPersonales { get; set; }
    }

    // Tabla: Cntr_Datos_Per
    public class DatosPersonales
    {
        [Key]
        public int Trabajador { get; set; }

        [Required]
        public int IdTrabajador { get; set; }

        [MaxLength(20)]
        public string? NumImss { get; set; }

        [MaxLength(250)]
        public string? Direccion { get; set; }

        [MaxLength(18)]
        public string? CURP { get; set; }

        [MaxLength(20)]
        public string? Telefono { get; set; }

        [ForeignKey(nameof(IdTrabajador)), JsonIgnore]
        public Trabajador? TrabajadorRef { get; set; }
    }
}
