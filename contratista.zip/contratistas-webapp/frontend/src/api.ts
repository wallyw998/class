import {
  ContratistaFormData,
  ContratistaFila,
  TrabajadorFormData,
  TrabajadorFila,
} from "./types";

const API_BASE_URL = "http://localhost:4000/api";

async function manejarRespuesta<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const cuerpo = await res.json().catch(() => ({}));
    throw new Error(cuerpo.mensaje || `Error ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export async function crearContratista(data: ContratistaFormData) {
  const res = await fetch(`${API_BASE_URL}/contratistas`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return manejarRespuesta<{ idContratistas: number; mensaje: string }>(res);
}

// filtros: objeto { nombreComercial: "abc", rfc: "xyz", ... } -> se convierte en query string
export async function obtenerContratistas(
  filtros: Record<string, string> = {}
): Promise<ContratistaFila[]> {
  const query = new URLSearchParams(
    Object.entries(filtros).filter(([, v]) => v.trim() !== "")
  ).toString();

  const res = await fetch(`${API_BASE_URL}/contratistas${query ? `?${query}` : ""}`);
  return manejarRespuesta<ContratistaFila[]>(res);
}

export async function crearTrabajador(data: TrabajadorFormData) {
  const res = await fetch(`${API_BASE_URL}/trabajadores`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return manejarRespuesta<{ idTrabajador: number; mensaje: string }>(res);
}

export async function obtenerTrabajadores(
  filtros: Record<string, string> = {}
): Promise<TrabajadorFila[]> {
  const query = new URLSearchParams(
    Object.entries(filtros).filter(([, v]) => v.trim() !== "")
  ).toString();

  const res = await fetch(`${API_BASE_URL}/trabajadores${query ? `?${query}` : ""}`);
  return manejarRespuesta<TrabajadorFila[]>(res);
}
